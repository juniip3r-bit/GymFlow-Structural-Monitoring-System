%% GymFlow Phase 7.5
% Visual Risk Dashboard

clear;
clc;
close all;


%% Current Values

riskScore = 68.7;

peakVibration = 0.058;
averageVibration = 0.006;
eventCount = 11;
occupancy = 15;


%% Determine Status Color

if riskScore < 25

    status = "SAFE";
    color = [0 0.7 0];

elseif riskScore < 50

    status = "ELEVATED";
    color = [1 0.8 0];

elseif riskScore < 75

    status = "EXCESSIVE";
    color = [1 0.5 0];

else

    status = "POTENTIALLY UNSAFE";
    color = [1 0 0];

end


%% Create Dashboard

figure

set(gcf,'Position',[300 200 600 500])

axis off


text(0.5,0.9,...
    "GYMFLOW " + ...
    "STRUCTURAL MONITORING SYSTEM",...
    'HorizontalAlignment','center',...
    'FontSize',18,...
    'FontWeight','bold')


rectangle(...
    'Position',[0.25 0.55 0.5 0.2],...
    'FaceColor',color,...
    'EdgeColor','k',...
    'LineWidth',2)


text(0.5,0.65,status,...
    'HorizontalAlignment','center',...
    'FontSize',18,...
    'FontWeight','bold')


text(0.5,0.45,...
    sprintf("Risk Score: %.1f%%",riskScore),...
    'HorizontalAlignment','center',...
    'FontSize',14)


text(0.5,0.35,...
    sprintf("Peak Vibration: %.3f m/s^2",peakVibration),...
    'HorizontalAlignment','center')


text(0.5,0.28,...
    sprintf("Average Vibration: %.3f m/s^2",averageVibration),...
    'HorizontalAlignment','center')


text(0.5,0.21,...
    sprintf("Events Detected: %d",eventCount),...
    'HorizontalAlignment','center')


text(0.5,0.14,...
    sprintf("Occupancy: %d People",occupancy),...
    'HorizontalAlignment','center')


axis([0 1 0 1])