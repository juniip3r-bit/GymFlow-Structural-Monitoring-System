%% ==========================================================
% GymFlow Project
% Phase 3 - Inspect Dataset
%
% This script displays the fields inside each dataset.
%% ==========================================================

clear;
clc;
close all;

%% Load data

load('floor_vibration_acceleration.mat')
load('zone_occupancy.mat')
load('zone_metadata.mat')

%% Display field names

disp('Fields in floor_vibration:')
fieldnames(floor_vibration)

disp(' ')

disp('Fields in zone_occupancy:')
fieldnames(zone_occupancy)

disp(' ')

disp('Fields in zones:')
fieldnames(zones)