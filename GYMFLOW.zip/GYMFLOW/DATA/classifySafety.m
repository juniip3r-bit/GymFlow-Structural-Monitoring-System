%% ==========================================================
% GymFlow Project
% Phase 6 - Safety Classification
%
% Purpose:
% Classify the current structural condition of the gym
% using vibration measurements.
%% ==========================================================

clear;
clc;
close all;

%% Load data

load('floor_vibration_acceleration.mat')

%% Extract vibration data

vibration = floor_vibration.rms_accel_m_s2;

%% Remove missing values

vibration = vibration(~isnan(vibration));

%% Calculate statistics

peakVibration = max(vibration);
averageVibration = mean(vibration);

%% Classification Thresholds
% (These will be improved later using occupancy data.)

if peakVibration < 0.015

    status = "NORMAL";
    color = [0 0.7 0];

elseif peakVibration < 0.030

    status = "ELEVATED";
    color = [1 0.8 0];

elseif peakVibration < 0.045

    status = "HIGH";
    color = [1 0.5 0];

else

    status = "EXTREME";
    color = [1 0 0];

end

%% Display Results

fprintf('\n');
fprintf('==============================\n');
fprintf('STRUCTURAL SAFETY STATUS\n');
fprintf('==============================\n');

fprintf('Peak Vibration: %.3f m/s^2\n',peakVibration);
fprintf('Average Vibration: %.3f m/s^2\n',averageVibration);
fprintf('Status: %s\n',status);

%% Create Status Indicator

figure

axis([0 1 0 1])

rectangle( ...
    'Position',[0.2 0.3 0.6 0.4], ...
    'FaceColor',color, ...
    'EdgeColor','k', ...
    'LineWidth',2)

text(0.5,0.5,status,...
    'HorizontalAlignment','center',...
    'FontSize',18,...
    'FontWeight','bold')

title('Gym Structural Safety Indicator')

axis off