%% GymFlow Phase 7
% Intelligent Structural Risk Analysis

clear;
clc;
close all;

%% Load vibration data

load('floor_vibration_acceleration.mat')

vibration = floor_vibration.rms_accel_m_s2;

vibration = vibration(~isnan(vibration));


%% Calculate vibration metrics

peakVibration = max(vibration);
averageVibration = mean(vibration);

%% Vibration Event Detection

% Difference between each vibration sample
changeRate = diff(vibration);


% Detect sudden increases
eventThreshold = 0.015;

events = abs(changeRate) > eventThreshold;


% Count vibration events
eventCount = sum(events);


%% Display Event Information

fprintf("Detected Events: %d\n",eventCount)

%% Event Severity

if eventCount == 0

    eventStatus = "NO SIGNIFICANT EVENTS";

elseif eventCount <= 5

    eventStatus = "NORMAL ACTIVITY EVENTS";

elseif eventCount <= 15

    eventStatus = "FREQUENT VIBRATION EVENTS";

else

    eventStatus = "HIGH IMPACT ACTIVITY";

end


fprintf("Event Status: %s\n",eventStatus)

%% Temporary occupancy input

occupancy = 15;


%% Display information

fprintf("==============================\n")
fprintf("GYMFLOW RISK ANALYSIS\n")
fprintf("==============================\n")

fprintf("Peak Vibration: %.3f m/s^2\n",peakVibration)
fprintf("Average Vibration: %.3f m/s^2\n",averageVibration)
fprintf("Occupancy: %d people\n",occupancy)

%% GymFlow Risk Score Calculation

% Normalize vibration risk

peakRisk = (peakVibration / 0.06) * 40;

averageRisk = (averageVibration / 0.01) * 20;


% Event risk

eventRisk = (eventCount / 20) * 20;


% Occupancy risk

occupancyRisk = (occupancy / 50) * 20;


% Total risk score

riskScore = peakRisk + averageRisk + eventRisk + occupancyRisk;


% Limit score to 100

if riskScore > 100
    riskScore = 100;
end


%% Determine Final Condition

if riskScore < 25

    finalStatus = "SAFE";

elseif riskScore < 50

    finalStatus = "ELEVATED";

elseif riskScore < 75

    finalStatus = "EXCESSIVE";

else

    finalStatus = "POTENTIALLY UNSAFE";

end


%% Display Final Result

fprintf("\n")
fprintf("==============================\n")
fprintf("GYMFLOW FINAL ASSESSMENT\n")
fprintf("==============================\n")

fprintf("Risk Score: %.1f%%\n",riskScore)
fprintf("Condition: %s\n",finalStatus)