%% ==========================================================
% GymFlow Project
% Phase 5 - Calculate Engineering Metrics
%
% Purpose:
% Calculate important structural safety metrics from
% floor vibration and occupancy data.
%% ==========================================================

clear;
clc;
close all;

%% Load datasets

load('floor_vibration_acceleration.mat')
load('zone_occupancy.mat')
load('zone_metadata.mat')

%% Extract vibration data

time = floor_vibration.time_sec;
rawVibration = floor_vibration.rms_accel_m_s2;

%% Basic vibration metrics
% Ignore missing (NaN) sensor values

peakVibration = max(rawVibration,[],'omitnan');

averageVibration = mean(rawVibration,'omitnan');

minimumVibration = min(rawVibration,[],'omitnan');

%% Occupancy metrics

people = zone_occupancy.occupancy_count;

maximumOccupancy = max(people);

averageOccupancy = mean(people);

%% Display results

disp('===============================')
disp('GYMFLOW ENGINEERING METRICS')
disp('===============================')

fprintf('Peak Vibration: %.3f m/s^2\n', peakVibration);
fprintf('Average Vibration: %.3f m/s^2\n', averageVibration);
fprintf('Minimum Vibration: %.3f m/s^2\n', minimumVibration);

fprintf('\n');

fprintf('Maximum Occupancy: %d people\n', maximumOccupancy);
fprintf('Average Occupancy: %.2f people\n', averageOccupancy);