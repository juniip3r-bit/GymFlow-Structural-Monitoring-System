%% ==========================================================
% GymFlow Project
% Phase 3 - Explore Sensor Data
%
% Purpose:
% This script loads the sensor datasets and displays
% information about their contents.
%% ==========================================================

clear;
clc;
close all;

%% Load datasets

load('floor_vibration_acceleration.mat')
load('zone_occupancy.mat')
load('zone_metadata.mat')

%% Display workspace variables

disp('==============================')
disp('WORKSPACE VARIABLES')
disp('==============================')

whos

%% Display information about each dataset

disp(' ')
disp('Floor Vibration Variable:')
class(floor_vibration)
size(floor_vibration)

disp(' ')
disp('Occupancy Variable:')
class(zone_occupancy)
size(zone_occupancy)

disp(' ')
disp('Zone Metadata:')
class(zones)
size(zones)