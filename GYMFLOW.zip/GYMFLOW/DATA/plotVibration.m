%% ==========================================================
% GymFlow Project
% Phase 4 - Plot Floor Vibration
%% ==========================================================

clear;
clc;
close all;

%% Load vibration data

load('floor_vibration_acceleration.mat')

%% Create a figure

figure

%% Plot RMS acceleration

plot(floor_vibration.time_sec,...
    floor_vibration.rms_accel_m_s2,...
    'b','LineWidth',2)

%% Improve appearance

xlabel('Time (seconds)')
ylabel('RMS Acceleration (m/s^2)')
title('Floor Vibration Over Time')

grid on