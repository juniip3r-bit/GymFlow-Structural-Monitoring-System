%% ==========================================================
% GymFlow Project
% Phase 6 - Detect Vibration Events
%
% Purpose:
% Count vibration events and display where they occur.
%% ==========================================================

clear;
clc;
close all;

%% Load dataset

load('floor_vibration_acceleration.mat')

%% Extract variables

time = floor_vibration.time_sec;
vibration = floor_vibration.rms_accel_m_s2;
eventFlag = floor_vibration.vibration_event_flag;

%% Count events

numberOfEvents = sum(eventFlag);

fprintf('Total Vibration Events Detected: %d\n', numberOfEvents);

%% Plot vibration

figure

plot(time, vibration, 'b')
hold on

%% Highlight detected events

plot(time(eventFlag==1), ...
    vibration(eventFlag==1), ...
    'ro', ...
    'MarkerFaceColor','r')

xlabel('Time (Seconds)')
ylabel('RMS Acceleration (m/s^2)')
title('Detected Floor Vibration Events')

legend('Vibration','Detected Event')

grid on