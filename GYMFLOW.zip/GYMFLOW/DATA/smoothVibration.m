%% ==========================================================
% GymFlow Project
% Phase 4 - Smooth Floor Vibration Data
%
% Purpose:
% This script smooths the raw floor vibration data using
% a moving average filter to reduce noise.
%% ==========================================================

clear;
clc;
close all;

%% Load vibration data
load('floor_vibration_acceleration.mat')

%% Extract variables from the structure
time = floor_vibration.time_sec;
rawVibration = floor_vibration.rms_accel_m_s2;

%% Smooth the signal using a moving average
windowSize = 10;
smoothedVibration = movmean(rawVibration, windowSize);

%% Plot raw and smoothed data
figure

plot(time, rawVibration, 'Color', [0.7 0.7 0.7], 'DisplayName', 'Raw Data')
hold on

plot(time, smoothedVibration, 'b', 'LineWidth', 2, 'DisplayName', 'Smoothed Data')

xlabel('Time (Seconds)')
ylabel('RMS Acceleration (m/s^2)')
title('Raw vs. Smoothed Floor Vibration')

legend
grid on