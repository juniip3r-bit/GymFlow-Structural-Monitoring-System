%% ==========================================================
%  GymFlow Project
%  Phase 2 - Load Sensor Data
%
%  Author: Your Name
%  Course: Civil Engineering Data Analytics
%
%  Purpose:
%  This script loads all sensor datasets needed for the
%  Smart Eco Gym dashboard.
%% ==========================================================

clear;
clc;
close all;

%% Load vibration dataset
load('floor_vibration_acceleration.mat')

%% Load occupancy dataset
load('zone_occupancy.mat')

%% Load zone information
load('zone_metadata.mat')

%% Display confirmation

disp('Datasets loaded successfully!')

%% Display variables currently in memory

whos